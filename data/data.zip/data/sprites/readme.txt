22 TorchDrippingYellow.png
Taken from: https://opengameart.org/content/alot-of-particles-torch-fire-special-effect-alotofparticle22
Copyright/Attribution Notice:  JoesAlotofthings
License(s): CC-BY 4.0

Full Coins.png
Taken from: https://opengameart.org/content/rotating-coin
Copyright/Attribution Notice:  100% To free use in another games and more.
License(s): CC0